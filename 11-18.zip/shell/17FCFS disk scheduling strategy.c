#include <stdio.h>
#include <stdlib.h>

#define MAX_REQUESTS 100

void fcfsDiskScheduling(int requests[], int numRequests, int initialPosition) {
    int current = initialPosition;
    int totalDistance = 0;

    printf("Sequence of disk access:\n");
    printf("%d", current);

    for (int i = 0; i < numRequests; i++) {
        int distance = abs(current - requests[i]);
        totalDistance += distance;
        current = requests[i];
        printf(" -> %d", current);
    }

    printf("\nTotal head movement: %d\n", totalDistance);
}

int main() {
    int requests[MAX_REQUESTS];
    int numRequests;
    int initialPosition;

    printf("Enter the number of disk requests: ");
    scanf("%d", &numRequests);

    printf("Enter the disk requests:\n");
    for (int i = 0; i < numRequests; i++) {
        scanf("%d", &requests[i]);
    }

    printf("Enter the initial head position: ");
    scanf("%d", &initialPosition);

    fcfsDiskScheduling(requests, numRequests, initialPosition);

    return 0;
}

