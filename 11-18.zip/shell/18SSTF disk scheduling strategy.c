#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdbool.h>

#define MAX_REQUESTS 100

int absDiff(int a, int b) {
    return abs(a - b);
}

int findClosest(int requests[], int numRequests, int current) {
    int closest = -1;
    int minDistance = INT_MAX;

    for (int i = 0; i < numRequests; i++) {
        int distance = absDiff(current, requests[i]);
        if (distance < minDistance) {
            minDistance = distance;
            closest = i;
        }
    }

    return closest;
}

void sstfDiskScheduling(int requests[], int numRequests, int initialPosition) {
    int current = initialPosition;
    int totalDistance = 0;
    bool visited[MAX_REQUESTS] = { false };

    printf("Sequence of disk access:\n");
    printf("%d", current);

    for (int i = 0; i < numRequests; i++) {
        int closest = findClosest(requests, numRequests, current);
        visited[closest] = true;
        int distance = absDiff(current, requests[closest]);
        totalDistance += distance;
        current = requests[closest];
        printf(" -> %d", current);
    }

    printf("\nTotal head movement: %d\n", totalDistance);
}

int main() {
    int requests[MAX_REQUESTS];
    int numRequests;
    int initialPosition;

    printf("Enter the number of disk requests: ");
    scanf("%d", &numRequests);

    printf("Enter the disk requests:\n");
    for (int i = 0; i < numRequests; i++) {
        scanf("%d", &requests[i]);
    }

    printf("Enter the initial head position: ");
    scanf("%d", &initialPosition);

    sstfDiskScheduling(requests, numRequests, initialPosition);

    return 0;
}

