#include <stdio.h>

#define MAX_FRAMES 10

int findPage(int pages[], int numPages, int page) {
    for (int i = 0; i < numPages; i++) {
        if (pages[i] == page) {
            return 1; // Page found in memory
        }
    }
    return 0; // Page not found in memory
}

void fifoPageReplacement(int pages[], int numPages, int numFrames) {
    int frames[MAX_FRAMES];
    int frameIndex = 0;
    int pageFaults = 0;
    
    // Initialize frames array with -1
    for (int i = 0; i < numFrames; i++) {
        frames[i] = -1;
    }
    
    for (int i = 0; i < numPages; i++) {
        int currentPage = pages[i];
        
        if (!findPage(frames, numFrames, currentPage)) {
            frames[frameIndex] = currentPage;
            frameIndex = (frameIndex + 1) % numFrames;
            pageFaults++;
        }
        
        printf("Page: %d\n", currentPage);
        printf("Frames: ");
        for (int j = 0; j < numFrames; j++) {
            if (frames[j] != -1) {
                printf("%d ", frames[j]);
            }
        }
        printf("\n");
    }
    
    printf("Page Faults: %d\n", pageFaults);
}

int main() {
    int numPages;
    int numFrames;
    int pages[MAX_FRAMES];
    
    printf("Enter the number of pages: ");
    scanf("%d", &numPages);
    
    printf("Enter the page reference string:\n");
    for (int i = 0; i < numPages; i++) {
        scanf("%d", &pages[i]);
    }
    
    printf("Enter the number of frames: ");
    scanf("%d", &numFrames);
    
    fifoPageReplacement(pages, numPages, numFrames);
    
    return 0;
}

