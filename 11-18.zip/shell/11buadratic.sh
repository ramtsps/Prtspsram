#!/bin/bash

echo "Quadratic Equation Solver"
echo "Enter the coefficients of the quadratic equation (ax^2 + bx + c):"

echo -n "Enter coefficient a: "
read a

echo -n "Enter coefficient b: "
read b

echo -n "Enter coefficient c: "
read c

# Calculate the discriminant
discriminant=$((b*b - 4*a*c))

# Check the value of the discriminant
if [ $discriminant -gt 0 ]; then
    # Two distinct real roots
    root1=$(bc <<< "scale=2; (-$b + sqrt($discriminant)) / (2*$a)")
    root2=$(bc <<< "scale=2; (-$b - sqrt($discriminant)) / (2*$a)")
    echo "Root 1: $root1"
    echo "Root 2: $root2"
elif [ $discriminant -eq 0 ]; then
    # One real root (repeated)
    root=$(bc <<< "scale=2; -$b / (2*$a)")
    echo "Root: $root"
else
    # Complex roots
    realPart=$(bc <<< "scale=2; -$b / (2*$a)")
    imaginaryPart=$(bc <<< "scale=2; sqrt(-$discriminant) / (2*$a)")
    echo "Root 1: $realPart + ${imaginaryPart}i"
    echo "Root 2: $realPart - ${imaginaryPart}i"
fi

