#!/bin/bash

echo -n "Enter a number: "
read number

length=${#number}

echo "Digits in odd positions:"

for ((i = 0; i < length; i++))
do
    if (( i % 2 == 0 ))
    then
        digit=${number:i:1}
        echo $digit
    fi
done

