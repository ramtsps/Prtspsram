#include <stdio.h>

#define MAX_FRAMES 10

int findPage(int pages[], int numPages, int page, int currentIndex) {
    for (int i = currentIndex; i < numPages; i++) {
        if (pages[i] == page) {
            return i; // Page found in future references
        }
    }
    return -1; // Page not found in future references
}

void optimalPageReplacement(int pages[], int numPages, int numFrames) {
    int frames[MAX_FRAMES];
    int pageFaults = 0;
    
    // Initialize frames array with -1
    for (int i = 0; i < numFrames; i++) {
        frames[i] = -1;
    }
    
    for (int i = 0; i < numPages; i++) {
        int currentPage = pages[i];
        
        if (findPage(frames, numFrames, currentPage, i) == -1) {
            int optimalPage = -1;
            int farthestPage = -1;
            
            for (int j = 0; j < numFrames; j++) {
                int pagePosition = findPage(pages, numPages, frames[j], i);
                
                if (pagePosition == -1) {
                    optimalPage = j;
                    break;
                } else {
                    if (pagePosition > farthestPage) {
                        farthestPage = pagePosition;
                        optimalPage = j;
                    }
                }
            }
            
            frames[optimalPage] = currentPage;
            pageFaults++;
        }
        
        printf("Page: %d\n", currentPage);
        printf("Frames: ");
        for (int j = 0; j < numFrames; j++) {
            if (frames[j] != -1) {
                printf("%d ", frames[j]);
            }
        }
        printf("\n");
    }
    
    printf("Page Faults: %d\n", pageFaults);
}

int main() {
    int numPages;
    int numFrames;
    int pages[MAX_FRAMES];
    
    printf("Enter the number of pages: ");
    scanf("%d", &numPages);
    
    printf("Enter the page reference string:\n");
    for (int i = 0; i < numPages; i++) {
        scanf("%d", &pages[i]);
    }
    
    printf("Enter the number of frames: ");
    scanf("%d", &numFrames);
    
    optimalPageReplacement(pages, numPages, numFrames);
    
    return 0;
}

