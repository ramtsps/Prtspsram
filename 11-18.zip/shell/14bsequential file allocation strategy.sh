#!/bin/bash

# Function to allocate a file in sequential manner
allocate_file() {
    local filename=$1
    local size=$2

    # Check if the file already exists
    if [ -f "$filename" ]; then
        echo "File $filename already exists."
        return
    fi

    # Check if the file system has enough space
    local available_space=$(df --output=avail . | tail -n1)
    if [ $size -gt $available_space ]; then
        echo "Not enough space to allocate file $filename."
        return
    fi

    # Allocate the file by creating a zero-filled file with the specified size
    dd if=/dev/zero of="$filename" bs=1 count=0 seek="$size" &>/dev/null
    echo "File $filename allocated successfully with size $size bytes."
}

# Prompt the user to enter the file name and size
echo -n "Enter the file name: "
read filename

echo -n "Enter the file size (in bytes): "
read size

# Allocate the file using sequential file allocation strategy
allocate_file "$filename" "$size"

