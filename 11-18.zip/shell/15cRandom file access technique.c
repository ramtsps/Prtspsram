#include <stdio.h>

int main() {
    FILE *file;
    char ch;
    long position;

    // Open the file in binary mode
    file = fopen("example.txt", "rb");
    if (file == NULL) {
        printf("Failed to open the file.\n");
        return 1;
    }

    // Set the file position to a specific byte using fseek()
    position = 5; // Example: move to the 6th byte (0-based index)
    fseek(file, position, SEEK_SET);

    // Get the current file position using ftell()
    position = ftell(file);
    printf("Current file position: %ld\n", position);

    // Read and print the character at the current file position
    ch = fgetc(file);
    printf("Character at current position: %c\n", ch);

    // Close the file
    fclose(file);

    return 0;
}

