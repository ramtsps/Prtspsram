#include <stdio.h>

#define MAX_FRAMES 10

int findPage(int pages[], int numPages, int page) {
    for (int i = 0; i < numPages; i++) {
        if (pages[i] == page) {
            return i; // Page found in memory, return its index
        }
    }
    return -1; // Page not found in memory
}

void lruPageReplacement(int pages[], int numPages, int numFrames) {
    int frames[MAX_FRAMES];
    int counter[MAX_FRAMES];
    int pageFaults = 0;
    int time = 0;
    
    // Initialize frames and counter arrays
    for (int i = 0; i < numFrames; i++) {
        frames[i] = -1;
        counter[i] = 0;
    }
    
    for (int i = 0; i < numPages; i++) {
        int currentPage = pages[i];
        int pagePosition = findPage(frames, numFrames, currentPage);
        
        if (pagePosition == -1) {
            int lruPage = 0;
            int minCounter = counter[0];
            
            // Find the least recently used page in memory
            for (int j = 1; j < numFrames; j++) {
                if (counter[j] < minCounter) {
                    lruPage = j;
                    minCounter = counter[j];
                }
            }
            
            frames[lruPage] = currentPage;
            counter[lruPage] = time;
            pageFaults++;
        } else {
            counter[pagePosition] = time;
        }
        
        printf("Page: %d\n", currentPage);
        printf("Frames: ");
        for (int j = 0; j < numFrames; j++) {
            if (frames[j] != -1) {
                printf("%d ", frames[j]);
            }
        }
        printf("\n");
        
        time++;
    }
    
    printf("Page Faults: %d\n", pageFaults);
}

int main() {
    int numPages;
    int numFrames;
    int pages[MAX_FRAMES];
    
    printf("Enter the number of pages: ");
    scanf("%d", &numPages);
    
    printf("Enter the page reference string:\n");
    for (int i = 0; i < numPages; i++) {
        scanf("%d", &pages[i]);
    }
    
    printf("Enter the number of frames: ");
    scanf("%d", &numFrames);
    
    lruPageReplacement(pages, numPages, numFrames);
    
    return 0;
}

